/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-12.0.2-MariaDB, for osx10.20 (arm64)
--
-- Host: localhost    Database: nutzerkosten_db
-- ------------------------------------------------------
-- Server version	12.0.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `Aufenthalt`
--

DROP TABLE IF EXISTS `Aufenthalt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Aufenthalt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `ankunft` datetime(3) NOT NULL,
  `abreise` datetime(3) NOT NULL,
  `zaehlerAnkunft` double NOT NULL,
  `zaehlerAbreise` double NOT NULL,
  `uebernachtungenMitglieder` int(11) NOT NULL DEFAULT 0,
  `uebernachtungenGaeste` int(11) NOT NULL DEFAULT 0,
  `jahr` int(11) NOT NULL,
  `zaehlerId` int(11) DEFAULT NULL,
  `zaehlerAbreiseId` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Aufenthalt_userId_fkey` (`userId`),
  KEY `Aufenthalt_zaehlerId_fkey` (`zaehlerId`),
  KEY `Aufenthalt_zaehlerAbreiseId_fkey` (`zaehlerAbreiseId`),
  CONSTRAINT `Aufenthalt_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `Aufenthalt_zaehlerAbreiseId_fkey` FOREIGN KEY (`zaehlerAbreiseId`) REFERENCES `Zaehler` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Aufenthalt_zaehlerId_fkey` FOREIGN KEY (`zaehlerId`) REFERENCES `Zaehler` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Aufenthalt`
--

LOCK TABLES `Aufenthalt` WRITE;
/*!40000 ALTER TABLE `Aufenthalt` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `Aufenthalt` VALUES
(1,21,'2024-08-14 22:00:00.000','2024-08-19 22:00:00.000',1250,1280,5,0,2024,3,3,'2025-09-04 13:03:21.725','2025-09-04 13:03:21.725'),
(2,27,'2024-08-24 22:00:00.000','2024-08-29 22:00:00.000',1280,1310,5,2,2024,3,3,'2025-09-04 13:03:29.255','2025-09-04 13:03:29.255'),
(4,24,'2024-09-10 00:00:00.000','2024-09-15 00:00:00.000',1335,1360,5,0,2024,3,3,'2025-09-04 13:16:22.749','2025-09-04 13:16:22.749'),
(13,21,'2024-08-20 00:00:00.000','2024-08-25 00:00:00.000',1270,1285,5,0,2024,3,3,'2025-09-05 09:37:09.663','2025-09-05 09:37:09.663'),
(17,21,'2024-09-12 00:00:00.000','2024-10-20 00:00:00.000',1350,1360,38,10,2024,3,3,'2025-09-05 09:53:42.529','2025-09-05 09:53:42.529'),
(24,27,'2024-10-02 00:00:00.000','2024-11-20 00:00:00.000',1480,10600,50,0,2024,3,3,'2025-09-05 10:50:17.275','2025-09-05 10:50:17.275'),
(25,21,'2025-01-15 00:00:00.000','2025-01-20 00:00:00.000',1400,1450,5,0,2025,3,3,'2025-09-05 11:09:48.593','2025-09-05 11:09:48.593'),
(26,22,'2025-09-04 00:00:00.000','2025-09-05 00:00:00.000',11000,11050,1,0,2025,3,3,'2025-09-05 11:11:05.490','2025-09-05 11:11:05.490'),
(27,22,'2025-09-04 00:00:00.000','2025-09-05 00:00:00.000',12000,12050,1,0,2025,3,3,'2025-09-05 11:38:45.832','2025-09-05 11:38:45.832'),
(28,22,'2025-09-04 00:00:00.000','2025-09-05 00:00:00.000',13000,13050,1,0,2025,3,3,'2025-09-05 11:39:14.596','2025-09-05 11:39:14.596');
/*!40000 ALTER TABLE `Aufenthalt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `JahresAbschluss`
--

DROP TABLE IF EXISTS `JahresAbschluss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `JahresAbschluss` (
  `jahr` int(11) NOT NULL,
  `zaehlerstand` double NOT NULL,
  `gesamtKosten` double NOT NULL,
  `anzahlAufenthalte` int(11) NOT NULL,
  `verbrauchProStunde` double NOT NULL,
  PRIMARY KEY (`jahr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JahresAbschluss`
--

LOCK TABLES `JahresAbschluss` WRITE;
/*!40000 ALTER TABLE `JahresAbschluss` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `JahresAbschluss` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `Preise`
--

DROP TABLE IF EXISTS `Preise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Preise` (
  `jahr` int(11) NOT NULL,
  `oelpreisProLiter` double NOT NULL,
  `uebernachtungMitglied` double NOT NULL,
  `uebernachtungGast` double NOT NULL,
  `verbrauchProStunde` double NOT NULL DEFAULT 5.5,
  `istBerechnet` tinyint(1) NOT NULL DEFAULT 0,
  `gueltigAb` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`jahr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Preise`
--

LOCK TABLES `Preise` WRITE;
/*!40000 ALTER TABLE `Preise` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `Preise` VALUES
(2024,1.3,15,25,6.666666666666667,1,NULL,'2025-09-04 13:03:58.528','2025-09-04 13:04:04.174'),
(2025,1.3,15,25,6.666666666666667,1,NULL,'2025-09-04 13:03:58.529','2025-09-04 13:04:04.175');
/*!40000 ALTER TABLE `Preise` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `Tankfuellung`
--

DROP TABLE IF EXISTS `Tankfuellung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Tankfuellung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datum` datetime(3) NOT NULL,
  `liter` double NOT NULL,
  `preisProLiter` double NOT NULL,
  `zaehlerstand` double NOT NULL,
  `zaehlerId` int(11) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `Tankfuellung_zaehlerId_fkey` (`zaehlerId`),
  CONSTRAINT `Tankfuellung_zaehlerId_fkey` FOREIGN KEY (`zaehlerId`) REFERENCES `Zaehler` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tankfuellung`
--

LOCK TABLES `Tankfuellung` WRITE;
/*!40000 ALTER TABLE `Tankfuellung` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `Tankfuellung` VALUES
(1,'2024-08-10 12:00:00.000',500,1.25,1200,3,'2025-09-04 13:03:51.747'),
(2,'2024-08-20 12:00:00.000',300,1.3,1250,3,'2025-09-04 13:03:58.526'),
(3,'2024-09-01 12:00:00.000',400,1.35,1310,3,'2025-09-04 13:04:04.172');
/*!40000 ALTER TABLE `Tankfuellung` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `TerminAbstimmung`
--

DROP TABLE IF EXISTS `TerminAbstimmung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TerminAbstimmung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `terminPlanungId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `stimme` enum('APPROVE','NEED_INFO') NOT NULL,
  `kommentar` varchar(191) DEFAULT NULL,
  `version` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `TerminAbstimmung_terminPlanungId_fkey` (`terminPlanungId`),
  KEY `TerminAbstimmung_userId_fkey` (`userId`),
  CONSTRAINT `TerminAbstimmung_terminPlanungId_fkey` FOREIGN KEY (`terminPlanungId`) REFERENCES `TerminPlanung` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `TerminAbstimmung_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TerminAbstimmung`
--

LOCK TABLES `TerminAbstimmung` WRITE;
/*!40000 ALTER TABLE `TerminAbstimmung` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `TerminAbstimmung` VALUES
(24,2,22,'APPROVE',NULL,4,'2025-09-05 15:11:39.493','2025-09-05 15:11:39.493');
/*!40000 ALTER TABLE `TerminAbstimmung` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `TerminAenderung`
--

DROP TABLE IF EXISTS `TerminAenderung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TerminAenderung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `terminPlanungId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `alteStartDatum` datetime(3) NOT NULL,
  `alteEndDatum` datetime(3) NOT NULL,
  `neueStartDatum` datetime(3) NOT NULL,
  `neueEndDatum` datetime(3) NOT NULL,
  `grund` varchar(191) DEFAULT NULL,
  `version` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  PRIMARY KEY (`id`),
  KEY `TerminAenderung_terminPlanungId_fkey` (`terminPlanungId`),
  KEY `TerminAenderung_userId_fkey` (`userId`),
  CONSTRAINT `TerminAenderung_terminPlanungId_fkey` FOREIGN KEY (`terminPlanungId`) REFERENCES `TerminPlanung` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `TerminAenderung_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TerminAenderung`
--

LOCK TABLES `TerminAenderung` WRITE;
/*!40000 ALTER TABLE `TerminAenderung` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `TerminAenderung` VALUES
(1,2,21,'2024-12-15 00:00:00.000','2024-12-20 00:00:00.000','2024-12-15 00:00:00.000','2024-12-19 00:00:00.000',NULL,2,'2025-09-05 14:17:51.493'),
(2,2,21,'2024-12-15 00:00:00.000','2024-12-19 00:00:00.000','2024-12-15 00:00:00.000','2024-12-17 00:00:00.000',NULL,3,'2025-09-05 14:24:37.374'),
(3,1,21,'2026-06-05 00:00:00.000','2026-07-05 00:00:00.000','2026-06-05 00:00:00.000','2026-07-11 00:00:00.000',NULL,2,'2025-09-05 14:47:43.675'),
(4,2,21,'2024-12-15 00:00:00.000','2024-12-17 00:00:00.000','2024-12-15 00:00:00.000','2024-12-24 00:00:00.000',NULL,4,'2025-09-05 14:57:36.691');
/*!40000 ALTER TABLE `TerminAenderung` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `TerminKommentar`
--

DROP TABLE IF EXISTS `TerminKommentar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TerminKommentar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `terminPlanungId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `inhalt` varchar(191) NOT NULL,
  `version` int(11) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `parentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `TerminKommentar_terminPlanungId_fkey` (`terminPlanungId`),
  KEY `TerminKommentar_userId_fkey` (`userId`),
  KEY `TerminKommentar_parentId_fkey` (`parentId`),
  CONSTRAINT `TerminKommentar_parentId_fkey` FOREIGN KEY (`parentId`) REFERENCES `TerminKommentar` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `TerminKommentar_terminPlanungId_fkey` FOREIGN KEY (`terminPlanungId`) REFERENCES `TerminPlanung` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `TerminKommentar_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TerminKommentar`
--

LOCK TABLES `TerminKommentar` WRITE;
/*!40000 ALTER TABLE `TerminKommentar` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `TerminKommentar` VALUES
(1,2,22,'Das passt mir gut!',1,'2025-09-05 13:30:54.912',NULL),
(2,2,22,'Das ist ein Test-Kommentar',1,'2025-09-05 13:42:35.271',NULL),
(3,2,22,'Das ist eine Antwort auf den Kommentar',1,'2025-09-05 13:42:40.733',2),
(4,2,22,'Das ist eine Antwort auf den Kommentar',1,'2025-09-05 13:45:15.890',2),
(5,2,21,'mein senf',1,'2025-09-05 13:45:44.794',2),
(6,2,21,'auch dazu',1,'2025-09-05 13:46:11.263',1),
(7,2,22,'Test-Kommentar aus Detailansicht',1,'2025-09-05 13:47:52.442',NULL),
(8,2,22,'ef',3,'2025-09-05 14:55:51.158',1);
/*!40000 ALTER TABLE `TerminKommentar` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `TerminPlanung`
--

DROP TABLE IF EXISTS `TerminPlanung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `TerminPlanung` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `titel` varchar(191) NOT NULL,
  `startDatum` datetime(3) NOT NULL,
  `endDatum` datetime(3) NOT NULL,
  `beschreibung` varchar(191) DEFAULT NULL,
  `status` enum('PENDING','APPROVED','DISCUSSING','CANCELLED') NOT NULL DEFAULT 'PENDING',
  `version` int(11) NOT NULL DEFAULT 1,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `TerminPlanung_userId_fkey` (`userId`),
  CONSTRAINT `TerminPlanung_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TerminPlanung`
--

LOCK TABLES `TerminPlanung` WRITE;
/*!40000 ALTER TABLE `TerminPlanung` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `TerminPlanung` VALUES
(1,21,'sommer 2026','2026-06-05 00:00:00.000','2026-07-11 00:00:00.000','das wuerde unser urlaub sein. passt das?','PENDING',3,'2025-09-05 12:07:36.252','2025-09-05 15:10:22.035'),
(2,21,'Test Terminplanung','2024-12-15 00:00:00.000','2024-12-24 00:00:00.000','Test für das Abstimmungssystem','PENDING',4,'2025-09-05 13:19:43.976','2025-09-05 14:57:36.688'),
(3,21,'Herbstferien 2025','2025-10-15 00:00:00.000','2025-10-25 23:59:59.999','Herbstferien mit der Familie','PENDING',1,'2025-09-05 13:57:33.485','2025-09-05 13:57:33.485');
/*!40000 ALTER TABLE `TerminPlanung` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `role` enum('ADMIN','USER') NOT NULL DEFAULT 'USER',
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `password` varchar(191) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `User` VALUES
(21,'post@christoph-heim.de','Christoph Heim','ADMIN','2025-09-03 08:37:20.332','$2b$10$wN2pZG6/1UvLxz3Ql1RHv.s8WjpnXV4lK28FtShJ/lNWTz9pjiiXC'),
(22,'usheim@t-online.de','Ulrich Heim','USER','2025-09-03 08:37:20.335','$2b$10$AxjQpYJfHNZZQxwRR.PJVuMAX3Xbl32ppD8yOcE5hGfuUH3Gp/FPe'),
(23,'markus.wilson-zwilling@gmx.de','Markus Wilson-Zwilling','USER','2025-09-03 08:37:20.336','$2b$10$wN2pZG6/1UvLxz3Ql1RHv.s8WjpnXV4lK28FtShJ/lNWTz9pjiiXC'),
(24,'okatomi.wilson@googlemail.com','Andreas Wilson','USER','2025-09-03 08:37:20.336','$2b$10$wN2pZG6/1UvLxz3Ql1RHv.s8WjpnXV4lK28FtShJ/lNWTz9pjiiXC'),
(25,'mail@tanzinbewegung.de','Astrid Tiedemann','USER','2025-09-03 08:37:20.337','$2b$10$wN2pZG6/1UvLxz3Ql1RHv.s8WjpnXV4lK28FtShJ/lNWTz9pjiiXC'),
(27,'andra.heim@gmx.de','Alexandra Heim','USER','2025-09-04 12:58:21.360','$2b$10$wN2pZG6/1UvLxz3Ql1RHv.s8WjpnXV4lK28FtShJ/lNWTz9pjiiXC');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `Zaehler`
--

DROP TABLE IF EXISTS `Zaehler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `Zaehler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `einbauDatum` datetime(3) NOT NULL,
  `ausbauDatum` datetime(3) DEFAULT NULL,
  `letzterStand` double NOT NULL,
  `istAktiv` tinyint(1) NOT NULL DEFAULT 1,
  `notizen` varchar(191) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Zaehler`
--

LOCK TABLES `Zaehler` WRITE;
/*!40000 ALTER TABLE `Zaehler` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `Zaehler` VALUES
(1,'2025-09-04 13:01:36.765','2025-09-04 13:02:02.810',0,0,NULL,'2025-09-04 13:01:36.765','2025-09-04 13:02:02.811'),
(2,'2025-09-04 13:02:02.813','2025-09-04 13:02:08.465',0,0,NULL,'2025-09-04 13:02:02.813','2025-09-04 13:02:08.465'),
(3,'2025-09-04 13:02:08.466',NULL,0,1,NULL,'2025-09-04 13:02:08.467','2025-09-04 13:02:08.467');
/*!40000 ALTER TABLE `Zaehler` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) NOT NULL,
  `logs` text DEFAULT NULL,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT current_timestamp(3),
  `applied_steps_count` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `_prisma_migrations` VALUES
('1487d6ff-2980-4450-9e6d-6720cb95516f','9e06ed20488f519ffece77af9f4bd5feb591d842fde490c825ab988f231996ab','2025-09-05 13:39:24.235','20250905133924_add_comment_threads',NULL,NULL,'2025-09-05 13:39:24.121',1),
('3c545dd9-9f0f-47ac-bf65-edf10ca6555a','749b56dbde8d203bcd9a6853caeb386842b8becacb994c240aa32706eb46e47d','2025-09-05 15:14:15.057','20250905151405_add_password_field',NULL,NULL,'2025-09-05 15:14:15.004',1),
('42ebc888-cf0c-427f-949f-e70ddc256079','1f2d0a61e1590e679045ad92cf11398b0a23c5b408665e04a9a1987971023338','2025-09-04 12:41:11.897','20250904124111_init_mysql',NULL,NULL,'2025-09-04 12:41:11.560',1),
('bb3eb3f1-4fdd-4a58-880d-b14b29690fc3','a1fa32798f1352b4bb691c07a3bac1ce657f3b1156f583d29679c7fca0e547e2','2025-09-05 12:01:31.381','20250905120130_add_termin_planung',NULL,NULL,'2025-09-05 12:01:30.900',1),
('d9a12511-ea1a-47f8-bad0-9f7d76e7fcee','588a9c24c0df19a7e95e3ca2819f87c9acc20a9f6134ac1620350828152fe6dc','2025-09-05 15:14:28.799','20250905151428_passwds',NULL,NULL,'2025-09-05 15:14:28.740',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-09-05 17:30:02
